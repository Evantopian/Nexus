defmodule ChatSystem.Mailer do
  use Swoosh.Mailer, otp_app: :chat_system
end
